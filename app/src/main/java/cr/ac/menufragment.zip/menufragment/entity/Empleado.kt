package cr.ac.menufragment.entity

import android.media.Image
import android.widget.ImageView
import java.io.Serializable

class Empleado(val id : String, val nombre : String, val puesto : String, val departamento : String, val imagen : Int):Serializable {

}