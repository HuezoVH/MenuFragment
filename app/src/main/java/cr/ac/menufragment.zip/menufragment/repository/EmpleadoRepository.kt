package cr.ac.menufragment.repository

import cr.ac.menufragment.entity.Empleado

class EmpleadoRepository {
    val empleados : HashMap<String, Empleado> = HashMap()

    companion object{
        @JvmStatic
        val instance by lazy{
            EmpleadoRepository().apply {  }
        }
    }

    constructor(){
        save(Empleado("1", "Gabriel Viquez", "Estudiante", "UNA", 0))
    }

    fun save(empleado: Empleado){
        empleados[empleado.id] = empleado
    }

    fun edit(empleado: Empleado){
        empleados[empleado.id] = empleado
    }

    fun delete (id : String){
        empleados.remove(id)
    }

    fun data():List<Empleado>{
        return empleados.values.toList()
    }
}