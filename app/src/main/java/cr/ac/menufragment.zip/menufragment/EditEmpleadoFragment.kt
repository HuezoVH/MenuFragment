package cr.ac.menufragment

import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputEditText
import cr.ac.menufragment.entity.Empleado
import cr.ac.menufragment.repository.EmpleadoRepository

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [EditEmpleadoFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class EditEmpleadoFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var empleado: Empleado? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            empleado = it.get(ARG_PARAM1) as Empleado?
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var view : View = inflater.inflate(R.layout.fragment_edit_empleado, container, false)
        val edit_id = view.findViewById<TextInputEditText>(R.id.edit_id)
        val edit_nombre = view.findViewById<TextInputEditText>(R.id.edit_nombre)
        val edit_puesto = view.findViewById<TextInputEditText>(R.id.edit_puesto)
        val edit_departamento = view.findViewById<TextInputEditText>(R.id.edit_departamento)

        //  Rellena los campos para editar
        edit_id.setText(empleado?.id)
        edit_nombre.setText(empleado?.nombre)
        edit_puesto.setText(empleado?.puesto)
        edit_departamento.setText(empleado?.departamento)

        view.findViewById<Button>(R.id.edit_cancelar_boton).setOnClickListener{ OnClickClose() }//en el on create
        view.findViewById<Button>(R.id.boton_editar).setOnClickListener{ OnClickEdit() }//en el on create
        view.findViewById<Button>(R.id.boton_eliminar).setOnClickListener { OnClickEliminar(edit_id.text.toString()) }
        return view
    }

    private fun OnClickEdit(){//crear esta funcion

        val edit_id = view?.findViewById<TextInputEditText>(R.id.edit_id)
        val edit_nombre = view?.findViewById<TextInputEditText>(R.id.edit_nombre)
        val edit_puesto = view?.findViewById<TextInputEditText>(R.id.edit_puesto)
        val edit_departamento = view?.findViewById<TextInputEditText>(R.id.edit_departamento)

        var empleado = Empleado(edit_id?.text.toString(), edit_nombre?.text.toString(), edit_puesto?.text.toString(), edit_departamento?.text.toString(), 1)
        EmpleadoRepository.instance.edit(empleado)

        var fragmento : Fragment = CamaraFragment.newInstance("Camara" )
        fragmentManager
            ?.beginTransaction()
            ?.replace(R.id.home_content, fragmento)
            ?.commit()
        activity?.setTitle("Camara")
    }

    private fun OnClickEliminar(identificacion:String){

        val builder = AlertDialog.Builder(context)
        builder.setMessage("¿Desea modificar el registro?")
            .setCancelable(false)
            .setPositiveButton("Sí") { dialog, id ->

                EmpleadoRepository.instance.delete(identificacion)
            }
            .setNegativeButton(
                "No"
            ) { dialog, id ->
                // logica del no
            }
        val alert = builder.create()
        alert.show()
//        var fragmento : Fragment = CamaraFragment.newInstance("Camara" )
//        fragmentManager
//            ?.beginTransaction()
//            ?.replace(R.id.home_content, fragmento)
//            ?.commit()
//        activity?.setTitle("Camara")
    }

    private fun OnClickClose(){//crear esta funcion
        var fragmento : Fragment = CamaraFragment.newInstance("Camara" )
        fragmentManager
            ?.beginTransaction()
            ?.replace(R.id.home_content, fragmento)
            ?.commit()
        activity?.setTitle("Camara")
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param empelado Parameter 1.
         * @return A new instance of fragment EditEmpleadoFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(empleado : Empleado) =
            EditEmpleadoFragment().apply {
                arguments = Bundle().apply {
                    putSerializable(ARG_PARAM1, empleado)
                }
            }
    }
}